#ifndef _ERROR_H
#define _ERROR_H 1

#include<stdio.h>
#define NUMBER 3

typedef enum {
  OK,
  MISSING_SEMI_COLON,
  MISSING_DOUBLE_QUOTES,
  MISSING_SINGLE_QUOTES,
  INVALID_CONSTANT,
  SYNTAX_ERROR,
  STACK_OVERFLOW,
  STACK_UNDERFLOW,
  UNKNOWN_DATATYPE,
  BAD_OPERAND,
  DIV_BY_ZERO,
  MEM_ERROR,
  DATA_TYPE_OVERFLOW,
  OPERATION_NOT_SUPPORTED,
  BAD_OPERATOR,
  
}Error;

extern char *err_values[] ;

extern Error err_type; 

extern void error(void);

#endif
