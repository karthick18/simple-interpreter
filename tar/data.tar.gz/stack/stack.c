/* The definition routines for stack.c */

#include <stack.h>

#include <stdio.h>

#include <stdlib.h>

#include <string.h> 

#include <error.h>

/* Initialise the globals in this file to the correct Values */

extern Error err_type;

int sc;

struct stack *stack_frame;

/* Initialise the stack*/

void stack_initialise(void) {
INIT_SC;
stack_frame = STACK_PTR;
}

/* Definition of the Push routine for stack. */

void stack_push(struct variable *var) { 

  /* check for overflow before pushing*/

  struct stack *esp;

 
   if (IS_STACK_OVERFLOW) {

      err_type = STACK_OVERFLOW;

      error(); 

   }

   /* push the value into the stack */

   esp = STACK_PTR;

   STACK_DECREMENT; //push

   esp->var = var ; //push the variable into the stack

   return ;

  }

/* The pop routine for stack.*/

struct variable *stack_pop(void) {  

  struct stack *esp;

  STACK_INCREMENT; //increment the stack

  if(IS_STACK_UNDERFLOW) {

   err_type =STACK_UNDERFLOW;
  
   error(); 

  }

  esp = STACK_PTR;
 
  return esp->var;

 } 

/* Lookup a stack for the local variable and value*/

struct variable *stack_lookup(char *key) { 

  struct stack *traverse;
  
  struct stack *esp = (struct stack *)STACK_PTR + 1;

  for(traverse=esp; traverse < stack_frame; traverse ++) 

    if(! strcmp(traverse->var->key,key) ) 

      return traverse->var;

  return (struct variable*) NULL;

}

/* On Function epilogue,release the stack memory */

void stack_free(){

  struct stack *traverse;

  struct stack *esp  = (struct stack *)STACK_PTR + 1;

  for(traverse=esp; traverse < stack_frame; traverse ++ ) {

    free((void*) traverse->var->key);

    deinstall_data(traverse->var->value);

    free((void*) traverse->var);

  }

 
 return;

}
    
    



