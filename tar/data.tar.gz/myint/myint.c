/* The integer object handling routine definitions */

#include <stdio.h>

#include <stdlib.h>

#include <string.h>

#include <data.h>

#include <myint.h>

#include <mystring.h>

#include <myfloat.h>

#include <mydouble.h>

#include <error.h>

extern Error err_type;

/* Declaration of the integer operation structure */


struct data *add_op(struct data *a,struct data *b ){

  /* A wrapper for int_operate */

  return int_operate(a,b,'+') ;

}


struct data *sub_op(struct data *a,struct data *b ){

  return int_operate(a,b,'-');

}

struct data *mul_op(struct data *a,struct data *b){

  return int_operate(a,b,'*');

}

struct data *div_op(struct data *a,struct data *b){

  return int_operate(a,b,'/');
}

struct data *compare_op(struct data *a,struct data *b,int op){

  return int_operate(a,b,op);

}

struct data *bit_op(struct data *a,struct data *b,int op) {

  return int_operate(a,b,op);

}


static struct object_operations operations = { 

  add_op,
  sub_op,
  mul_op,
  div_op,
  compare_op,
  bit_op,

/* Null terminated */

};


struct data* int_operate(struct data *a,struct data *b,int op){

  struct data *ptr = (struct data *) NULL;

  struct data_operations *dptr;

  switch(b->ele_type) {

    case _STR:

      CHECK_DPTR(dptr,_STR);

      switch(op) {

      case '+':
	
	ptr = dptr->op_ptr->add_op(a,b);  

      break;

      case '*':
     
        
        ptr = dptr->op_ptr->mul_op(a,b);

        break;

      default:

        err_type = BAD_OPERAND;

        error();

      }

      break;

    case _FLT:
      
      CHECK_DPTR(dptr,_FLT);

      switch(op) {

      case '+':
        
        ptr = dptr->op_ptr->add_op(a,b);
     
        break;

      case '-':
        
        ptr = dptr->op_ptr->sub_op(a,b);

        break;

      case '*':

        ptr = dptr->op_ptr->mul_op(a,b);

        break;

      case '/':

        ptr = dptr->op_ptr->div_op(a,b);

        break;

      default:

        err_type = BAD_OPERAND;

        error();

      }

      break;
       
    case _DBL:

      CHECK_DPTR(dptr,_DBL);

      switch(op) {

      case '+':

	ptr = dptr->op_ptr->add_op(a,b);
 
      break;

      case '-':

	ptr = dptr->op_ptr->sub_op(a,b);

        break;

      case '*' :

        ptr = dptr->op_ptr->mul_op(a,b);

        break;

      case '/':

        ptr = dptr->op_ptr->div_op(a,b);

        break;

      default:

        err_type = BAD_OPERAND;

        error();

      }

      break;

           
    case _INT:

      /* Make a data object by adding up the stuff */
      
      ptr = MALLOC_DATA;

      ptr->ele_type = _INT;

      switch(op) {

      case '+':

         ptr->INT_PTR = INSTALL_INT(a->INT_VALUE + b->INT_VALUE);
      
        break;

      case '-':

	ptr->INT_PTR = INSTALL_INT(a->INT_VALUE - b->INT_VALUE);

        break;

      case '*':

        ptr->INT_PTR = INSTALL_INT(a->INT_VALUE * b->INT_VALUE);

        break;

      case '/':

        if (! (b->INT_VALUE) ) {
 
          free((void*)ptr);
          
          err_type = DIV_BY_ZERO;

          error();

	}

        else 

	  ptr->INT_PTR = INSTALL_INT(a->INT_VALUE / b->INT_VALUE);
	
        break;
   

      case '>':  //comparison operators

        ptr->INT_PTR = INSTALL_INT (a->INT_VALUE > b->INT_VALUE);

        break;


      case '<':

        ptr->INT_PTR = INSTALL_INT (a->INT_VALUE < b->INT_VALUE);

        break;

      case '&' :

        ptr->INT_PTR = INSTALL_INT (a->INT_VALUE & b->INT_VALUE);

        break;

      case '|' :

        ptr->INT_PTR = INSTALL_INT (a->INT_VALUE | b->INT_VALUE);

        break;

      case '^' :

        ptr->INT_PTR = INSTALL_INT (a->INT_VALUE | b->INT_VALUE);

        break;

      default:

	err_type = BAD_OPERAND;
        error();

      }
 
      break;

    default :

      err_type = UNKNOWN_DATATYPE;

      error();

    } //end switch

  return ptr;

} //end routine  


struct int_type *install_int(int value){

  struct int_type *i;

  i = MALLOC_INT; //allocate an integer object
 
  if( !i) 
 
    {

      err_type = MEM_ERROR;

      error();
    }

  i->value = value;

  i->int_ptr = &operations ; //set up the operation pointer

  return i; 

}     


struct data *deinstall_int(struct data *ptr) {

  if( ptr) {

    if(ptr->INT_PTR)

      free((void*)ptr->INT_PTR);  

  }

  return ptr;

}




int register_int(void) {

  /* Register the data type */

  return register_data(&operations,_INT);

}


         
  



