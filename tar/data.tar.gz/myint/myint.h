#ifndef _MYINT_H 
#define _MYINT_H 1

#include<stdio.h>

#include<data.h>

#define INT_ADD 	1
#define INT_SUB 	2
#define INT_MUL  	3
#define INT_DIV         4
#define INT_RSHIFT	5
#define INT_LSHIFT	6
#define INT_OR	        7
#define INT_XOR		8
#define INT_AND		9
#define INT_NOT		10
#define INT_GREATER     11
#define INT_LESSER      12

#define INSTALL_INT(value) install_int(value) //install an integer data type

#define FREE_INT(data) deinstall_int(data) //free up an integer data

/* Declarations of installation and free routines,plus the declaration of the most important structure for definition of data types */


struct int_type {

  int value; 

  struct object_operations *int_ptr;

};


extern struct int_type *install_int(int value);

extern struct data *deinstall_int(struct data *);

/* The routine for integer operation */

extern struct data *int_operate(struct data *a,struct data *b,int what);

#endif
  







