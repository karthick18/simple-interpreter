#ifndef _MYFLOAT_H 
#define _MYFLOAT_H 1

#include<stdio.h>

#include<data.h>

/* Define the operations possible on float objects*/

#define FLOAT_ADD 	1
#define FLOAT_SUB 	2
#define FLOAT_MUL  	3
#define FLOAT_DIV       4

#define INSTALL_FLOAT(value) install_float(value) 

#define FREE_FLOAT(data) deinstall_float(data) 

/* Declarations of installation and free routines,plus the declaration of the most important structure for definition of data types */


struct flt_type {

  float value; 

  struct object_operations *flt_ptr;

};


extern struct flt_type *install_float(float value);

extern struct data *deinstall_float(struct data *data);


#endif
  




